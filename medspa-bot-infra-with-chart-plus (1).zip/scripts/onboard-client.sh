#!/usr/bin/env bash
set -euo pipefail
# See previous message for full usage; this is a minimal wrapper if artifacts were rebuilt.
echo "Onboarding script placeholder. Ensure helm-medspa-bot chart and helm-values-tiers exist."
