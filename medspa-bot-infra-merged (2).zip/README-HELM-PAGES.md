# Helm Chart Publishing via GitHub Pages (CI)

This workflow packages the Helm chart under `helm-medspa-bot/` and publishes it to the `gh-pages` branch
so your repository can serve as a **Helm repository**.

## Setup
1. Ensure your chart is in: `helm-medspa-bot/` (or change `CHART_DIR` in the workflow).
2. In GitHub **Settings → Pages**, set **Source** to branch: `gh-pages` (root).
3. Push to `main` after editing the chart — the workflow will package and publish.
4. Your Helm repo index will be available at:
   ```
   https://<user-or-org>.github.io/<repo>/index.yaml
   ```

## Use
```bash
helm repo add medspa https://<user-or-org>.github.io/<repo>/
helm repo update
helm install client-a medspa/medspa-bot \
  -f helm-medspa-bot/examples/values-client-a.yaml \
  -n medspa-client-a --create-namespace
```

## Notes
- Existing `index.yaml` is merged, preserving older versions.
- Chart `version` in `Chart.yaml` controls the package filename.
- To force a repackage, bump `version` or change chart contents.
