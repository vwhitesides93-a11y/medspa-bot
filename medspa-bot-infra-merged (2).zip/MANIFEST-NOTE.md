# Manifest Note
In your base `deployment.yaml`, set image to:
  image: ghcr.io/<YOUR_GH_USER_OR_ORG>/medspa-bot:latest
and ensure:
  imagePullPolicy: Always

The Docker workflow will publish :latest on push to main.
The deploy workflow applies overlays and restarts deployments so the new image is pulled.
