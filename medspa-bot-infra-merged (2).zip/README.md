# Med-Spa Bot — Infra Repo (Combined)

This repo includes **everything needed to operate multi-tenant Kubernetes deployments** with CI/CD:
- `k8s-medspa-bot-multitenant/` — base manifests + per-client overlays (namespaces, domains)
- `.github/workflows/` — CI pipelines
  - `docker-build-push.yml` — build & push Docker image to GHCR
  - `deploy-overlays.yml` — auto-apply changed overlays + rollout restart
  - `preview-pr-wildcard.yml` — per-PR preview environments with wildcard staging domains
- `MANIFEST-NOTE.md` — how to point Deployments to GHCR `:latest`
- `README-WILDCARD-PREVIEWS.md` — DNS & setup for previews
- `README-CI.md` — CI overview

## Required GitHub Secrets
- `KUBE_CONFIG` — kubeconfig content for cluster access (recommend a limited-scope service account)
- `STAGING_DOMAIN` — e.g. `staging.yourdomain.com` for wildcard previews (`*.staging.yourdomain.com` -> Ingress IP)

## One-time Setup
1. Set your base Deployment image to `ghcr.io/<YOUR_ORG_OR_USER>/medspa-bot:latest` and `imagePullPolicy: Always`.
2. Set repo secrets above.
3. Ensure your cluster has NGINX Ingress + cert-manager (with a `ClusterIssuer` named `letsencrypt-prod`).
4. Create DNS A record for `*.staging.yourdomain.com` to point to the Ingress LB (for previews).

## Usage
- Push to `main` → Docker image builds (`latest`) and overlays changed get applied automatically.
- Open a PR touching an overlay → preview env at `https://pr-<PR#>-<overlay>.<STAGING_DOMAIN>`; closes on PR close.
