# Overlay: client-a

Namespace: `medspa-client-a`  
Domain: `https://bot.client-a.example.com`

### Apply
```bash
kubectl apply -k .
```
(From this overlay folder.)

### What it does
- Sets unique namespace `medspa-client-a`
- Sets domain to `bot.client-a.example.com` in Ingress
- Sets BOOKING_URL to `https://www.vagaro.com/client-a/book`
- Adds name suffix `-client-a` to all resource names to avoid collisions
