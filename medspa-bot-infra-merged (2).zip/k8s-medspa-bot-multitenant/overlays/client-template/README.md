# Overlay: client-template

Namespace: `medspa-client-template`  
Domain: `https://bot.client-template.example.com`

### Apply
```bash
kubectl apply -k .
```
(From this overlay folder.)

### What it does
- Sets unique namespace `medspa-client-template`
- Sets domain to `bot.client-template.example.com` in Ingress
- Sets BOOKING_URL to `https://www.vagaro.com/client-template/book`
- Adds name suffix `-client-template` to all resource names to avoid collisions
