# Overlay: client-b

Namespace: `medspa-client-b`  
Domain: `https://bot.client-b.example.com`

### Apply
```bash
kubectl apply -k .
```
(From this overlay folder.)

### What it does
- Sets unique namespace `medspa-client-b`
- Sets domain to `bot.client-b.example.com` in Ingress
- Sets BOOKING_URL to `https://www.vagaro.com/client-b/book`
- Adds name suffix `-client-b` to all resource names to avoid collisions
