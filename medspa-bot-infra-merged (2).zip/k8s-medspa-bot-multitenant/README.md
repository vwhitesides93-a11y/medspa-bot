# Multi-tenant Kustomize — one namespace per client, unique domains

Structure:
```
base/        # shared manifests
overlays/
  client-template/  # copy this to create a new client
  client-a/
  client-b/
```

## Create a new client
1) Copy `overlays/client-template` to `overlays/<client-name>`
2) Edit:
   - `kustomization.yaml`: namespace & `nameSuffix`
   - `patch-configmap.yaml`: set `BOOKING_URL`, `CORS_ORIGINS`
   - `patch-ingress.yaml`: set the `host` and `tls.hosts`, and `secretName`
3) Apply from the client overlay folder:
```bash
kubectl apply -k overlays/<client-name>
```

> Make sure DNS for the client's domain points to your cluster's Ingress Controller IP and that `ClusterIssuer letsencrypt-prod` exists.
