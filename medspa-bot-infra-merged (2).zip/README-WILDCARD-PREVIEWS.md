# Wildcard Staging Domains for PR Previews

This workflow publishes **per-PR preview environments** on hosts like:
```
https://pr-<PR#>-<overlay>.staging.yourdomain.com
```
It requires a **wildcard DNS** record:
```
*.staging.yourdomain.com  ->  <Ingress Controller Public IP / LB DNS>
```

## Setup

1. In GitHub repo **Settings → Secrets and variables → Actions → New repository secret**:
   - `KUBE_CONFIG` — kubeconfig with access to your cluster
   - `STAGING_DOMAIN` — e.g. `staging.yourdomain.com`
   - (Optional) `KUBE_NAMESPACE_PREFIX` — default `medspa-pr-`

2. Ensure your cluster has:
   - **NGINX Ingress Controller**
   - **cert-manager** with a `ClusterIssuer` named `letsencrypt-prod` (or change the annotation in your base Ingress)

3. Ensure your base deployment image is pulling from GHCR `:latest` or the tag you build in CI.

## How it works
- On PR **open/sync/reopen**:
  - Creates a namespace `medspa-pr-<PR#>-<overlay>`
  - Applies the overlay with JSON6902 patches to:
    - set the **Ingress host** to `pr-<PR#>-<overlay>.<STAGING_DOMAIN>`
    - set the **TLS hosts** and a **unique secret name** per PR
- On PR **close**:
  - Deletes the preview namespace

> Certs will provision automatically per preview host via Let's Encrypt HTTP-01,
  assuming DNS wildcard points to the Ingress LB and the `letsencrypt-prod` ClusterIssuer exists.

## Notes
- If you prefer **one shared TLS secret** (wildcard cert), pre-provision it and change the patch to reuse that secret name.
- For multi-overlay PRs, this example picks the **first changed** overlay. You can extend it to loop over all changed overlays.
